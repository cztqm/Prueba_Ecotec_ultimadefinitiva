"""Punto de entrada de la aplicación de consola EcoTech Solutions."""

import sqlite3

from config.database import Database
from controllers.empleado_controller import EmpleadoController
from controllers.proyecto_controller import ProyectoController
from views.empleado_view import EmpleadoView
from views.proyecto_view import ProyectoView
from views.utils import leer_entero


def main() -> None:
    database = Database()
    try:
        database.init_db()
    except sqlite3.Error as exc:
        print(f"No fue posible iniciar la base de datos: {exc}")
        return

    empleado_view = EmpleadoView(EmpleadoController(database))
    proyecto_view = ProyectoView(ProyectoController(database))
    while True:
        print(
            "\n=== EcoTech Solutions ===\n"
            "1. Empleados y horas\n"
            "2. Proyectos y asignaciones\n"
            "0. Salir"
        )
        opcion = leer_entero("Seleccione una opción: ", minimo=0)
        if opcion == 0:
            print("Hasta luego.")
            break
        if opcion == 1:
            empleado_view.menu()
        elif opcion == 2:
            proyecto_view.menu()
        else:
            print("Opción no válida.")


if __name__ == "__main__":
    main()
