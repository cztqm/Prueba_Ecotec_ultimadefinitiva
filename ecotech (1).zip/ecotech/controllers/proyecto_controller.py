"""Operaciones de negocio y persistencia para proyectos y asignaciones."""

import math
import sqlite3
from typing import TypedDict

from config.database import Database
from models.empleado import Empleado
from models.proyecto import Proyecto


class DatosProyecto(TypedDict):
    nombre: str
    descripcion: str
    fecha_inicio: str


class ProyectoController:
    def __init__(self, database: Database) -> None:
        self.database = database

    def crear_proyecto(self, datos: DatosProyecto) -> int:
        proyecto = self._crear_modelo(datos)
        try:
            with self.database.transaction() as connection:
                cursor = connection.execute(
                    """INSERT INTO proyecto (nombre, descripcion, fecha_inicio)
                       VALUES (?, ?, ?)""",
                    (proyecto.nombre.strip(), proyecto.descripcion.strip(), proyecto.fecha_inicio),
                )
                return int(cursor.lastrowid)
        except sqlite3.Error as exc:
            raise RuntimeError(f"No se pudo crear el proyecto: {exc}") from exc

    def listar_proyectos(self) -> list[Proyecto]:
        try:
            with self.database.transaction() as connection:
                filas = connection.execute(
                    """SELECT p.id_proyecto, p.nombre, p.descripcion, p.fecha_inicio,
                              COUNT(ep.id_usuario) AS empleados_asignados,
                              COALESCE(SUM(ep.horas_asignadas), 0) AS horas_asignadas
                       FROM proyecto AS p
                       LEFT JOIN empleado_proyecto AS ep
                           ON ep.id_proyecto = p.id_proyecto
                       GROUP BY p.id_proyecto
                       ORDER BY p.nombre, p.id_proyecto"""
                ).fetchall()
                return [
                    Proyecto(
                        id_proyecto=fila["id_proyecto"],
                        nombre=fila["nombre"],
                        descripcion=fila["descripcion"] or "",
                        fecha_inicio=fila["fecha_inicio"],
                        empleados_asignados=fila["empleados_asignados"],
                        horas_asignadas=fila["horas_asignadas"],
                    )
                    for fila in filas
                ]
        except sqlite3.Error as exc:
            raise RuntimeError(f"No se pudieron listar los proyectos: {exc}") from exc

    def actualizar_proyecto(self, id_proyecto: int, datos: DatosProyecto) -> bool:
        proyecto = self._crear_modelo(datos)
        self._validar_id(id_proyecto)
        try:
            with self.database.transaction() as connection:
                cursor = connection.execute(
                    """UPDATE proyecto
                       SET nombre = ?, descripcion = ?, fecha_inicio = ?
                       WHERE id_proyecto = ?""",
                    (
                        proyecto.nombre.strip(),
                        proyecto.descripcion.strip(),
                        proyecto.fecha_inicio,
                        id_proyecto,
                    ),
                )
                return cursor.rowcount > 0
        except sqlite3.Error as exc:
            raise RuntimeError(f"No se pudo actualizar el proyecto: {exc}") from exc

    def eliminar_proyecto(self, id_proyecto: int) -> bool:
        self._validar_id(id_proyecto)
        try:
            with self.database.transaction() as connection:
                existe = connection.execute(
                    "SELECT 1 FROM proyecto WHERE id_proyecto = ?", (id_proyecto,)
                ).fetchone()
                if existe is None:
                    return False
                horas = connection.execute(
                    "SELECT COUNT(*) FROM tiempo WHERE id_proyecto = ?", (id_proyecto,)
                ).fetchone()[0]
                if horas:
                    raise ValueError(
                        "No se puede eliminar el proyecto porque tiene horas registradas. "
                        "El historial de horas se conserva."
                    )
                connection.execute(
                    "DELETE FROM proyecto WHERE id_proyecto = ?", (id_proyecto,)
                )
                return True
        except sqlite3.Error as exc:
            raise RuntimeError(f"No se pudo eliminar el proyecto: {exc}") from exc

    def listar_empleados(self) -> list[sqlite3.Row]:
        try:
            with self.database.transaction() as connection:
                return list(
                    connection.execute(
                        """SELECT u.id_usuario, u.nombre, u.email
                           FROM usuario AS u
                           JOIN empleado AS e ON e.id_usuario = u.id_usuario
                           ORDER BY u.nombre"""
                    ).fetchall()
                )
        except sqlite3.Error as exc:
            raise RuntimeError(f"No se pudieron listar los empleados: {exc}") from exc

    def listar_asignaciones(self, id_proyecto: int) -> list[sqlite3.Row]:
        self._validar_id(id_proyecto)
        try:
            with self.database.transaction() as connection:
                self._obtener_proyecto(connection, id_proyecto)
                return list(
                    connection.execute(
                        """SELECT u.id_usuario, u.nombre, u.email, ep.horas_asignadas
                           FROM empleado_proyecto AS ep
                           JOIN usuario AS u ON u.id_usuario = ep.id_usuario
                           WHERE ep.id_proyecto = ?
                           ORDER BY u.nombre""",
                        (id_proyecto,),
                    ).fetchall()
                )
        except sqlite3.Error as exc:
            raise RuntimeError(f"No se pudieron listar las asignaciones: {exc}") from exc

    def asignar_empleados(
        self, id_proyecto: int, asignaciones: list[tuple[int, float]]
    ) -> None:
        self._validar_id(id_proyecto)
        if not asignaciones:
            raise ValueError("Seleccione al menos un empleado para asignar.")
        ids_empleados: set[int] = set()
        for id_usuario, horas in asignaciones:
            self._validar_id(id_usuario)
            self._validar_horas_asignadas(horas)
            if id_usuario in ids_empleados:
                raise ValueError("No se puede seleccionar dos veces al mismo empleado.")
            ids_empleados.add(id_usuario)
        try:
            with self.database.transaction() as connection:
                proyecto = self._obtener_proyecto(connection, id_proyecto)
                for id_usuario, horas in asignaciones:
                    empleado = self._obtener_empleado(connection, id_usuario)
                    if any(
                        actual.id_usuario == id_usuario
                        for actual in proyecto.empleados
                    ):
                        raise ValueError("El empleado ya está asignado a este proyecto.")
                    asignacion = connection.execute(
                        """SELECT 1 FROM empleado_proyecto
                           WHERE id_usuario = ? AND id_proyecto = ?""",
                        (id_usuario, id_proyecto),
                    ).fetchone()
                    if asignacion is not None:
                        raise ValueError("El empleado ya está asignado a este proyecto.")
                    proyecto.asignar_empleado(empleado)
                    connection.execute(
                        """INSERT INTO empleado_proyecto
                           (id_usuario, id_proyecto, horas_asignadas)
                           VALUES (?, ?, ?)""",
                        (id_usuario, id_proyecto, horas),
                    )
        except sqlite3.IntegrityError as exc:
            raise RuntimeError(f"SQLite rechazó la asignación del empleado: {exc}") from exc
        except sqlite3.Error as exc:
            raise RuntimeError(f"No se pudieron asignar los empleados al proyecto: {exc}") from exc

    def asignar_empleado(self, id_proyecto: int, id_usuario: int) -> None:
        """Mantiene compatibilidad con asignaciones existentes sin horas planificadas."""
        self.asignar_empleados(id_proyecto, [(id_usuario, 0)])

    def actualizar_horas_asignadas(
        self, id_proyecto: int, id_usuario: int, horas_asignadas: float
    ) -> bool:
        self._validar_id(id_proyecto)
        self._validar_id(id_usuario)
        self._validar_horas_asignadas(horas_asignadas)
        try:
            with self.database.transaction() as connection:
                self._obtener_proyecto(connection, id_proyecto)
                cursor = connection.execute(
                    """UPDATE empleado_proyecto SET horas_asignadas = ?
                       WHERE id_usuario = ? AND id_proyecto = ?""",
                    (horas_asignadas, id_usuario, id_proyecto),
                )
                return cursor.rowcount > 0
        except sqlite3.Error as exc:
            raise RuntimeError(f"No se pudieron actualizar las horas asignadas: {exc}") from exc

    def desasignar_empleado(self, id_proyecto: int, id_usuario: int) -> None:
        try:
            with self.database.transaction() as connection:
                proyecto = self._obtener_proyecto(connection, id_proyecto)
                empleado = self._obtener_empleado(connection, id_usuario)
                asignacion = connection.execute(
                    """SELECT 1 FROM empleado_proyecto
                       WHERE id_usuario = ? AND id_proyecto = ?""",
                    (id_usuario, id_proyecto),
                ).fetchone()
                if asignacion is None:
                    raise ValueError("El empleado no está asignado a este proyecto.")
                proyecto.empleados.append(empleado)
                proyecto.desasignar_empleado(empleado)
                connection.execute(
                    """DELETE FROM empleado_proyecto
                       WHERE id_usuario = ? AND id_proyecto = ?""",
                    (id_usuario, id_proyecto),
                )
        except sqlite3.Error as exc:
            raise RuntimeError(f"No se pudo desasignar el empleado del proyecto: {exc}") from exc

    @staticmethod
    def _obtener_proyecto(connection: sqlite3.Connection, id_proyecto: int) -> Proyecto:
        fila = connection.execute(
            """SELECT id_proyecto, nombre, descripcion, fecha_inicio
               FROM proyecto WHERE id_proyecto = ?""",
            (id_proyecto,),
        ).fetchone()
        if fila is None:
            raise ValueError(f"No existe el proyecto con ID {id_proyecto}.")
        return Proyecto(
            id_proyecto=fila["id_proyecto"],
            nombre=fila["nombre"],
            descripcion=fila["descripcion"] or "",
            fecha_inicio=fila["fecha_inicio"],
        )

    @staticmethod
    def _obtener_empleado(connection: sqlite3.Connection, id_usuario: int) -> Empleado:
        fila = connection.execute(
            """SELECT u.id_usuario, u.nombre, u.email, u.contrasena_hash,
                      e.telefono, e.fecha_inicio_contrato, e.salario, e.id_departamento
               FROM usuario AS u
               JOIN empleado AS e ON e.id_usuario = u.id_usuario
               WHERE u.id_usuario = ?""",
            (id_usuario,),
        ).fetchone()
        if fila is None:
            raise ValueError(f"No existe el empleado con ID {id_usuario}.")
        return Empleado(
            id_usuario=fila["id_usuario"],
            nombre=fila["nombre"],
            email=fila["email"],
            contrasena_hash=fila["contrasena_hash"],
            telefono=fila["telefono"] or "",
            fecha_inicio_contrato=fila["fecha_inicio_contrato"],
            salario=fila["salario"],
            id_departamento=fila["id_departamento"],
        )

    @staticmethod
    def _crear_modelo(datos: DatosProyecto) -> Proyecto:
        try:
            campos = ("nombre", "descripcion", "fecha_inicio")
            if not isinstance(datos, dict) or any(
                not isinstance(datos[campo], str) for campo in campos
            ):
                raise ValueError("Nombre, descripción y fecha de inicio deben ser texto.")
            proyecto = Proyecto(
                nombre=datos["nombre"],
                descripcion=datos["descripcion"],
                fecha_inicio=datos["fecha_inicio"],
            )
        except (KeyError, TypeError) as exc:
            raise ValueError(
                "Los datos deben incluir nombre, descripcion y fecha_inicio."
            ) from exc
        if not proyecto.validar():
            raise ValueError("Ingrese un nombre y una fecha de inicio válida (AAAA-MM-DD).")
        return proyecto

    @staticmethod
    def _validar_id(id_proyecto: int) -> None:
        if not isinstance(id_proyecto, int) or isinstance(id_proyecto, bool) or id_proyecto <= 0:
            raise ValueError("El ID del proyecto debe ser un entero positivo.")

    @staticmethod
    def _validar_horas_asignadas(horas: float) -> None:
        if (
            not isinstance(horas, (int, float))
            or isinstance(horas, bool)
            or not math.isfinite(horas)
            or horas < 0
        ):
            raise ValueError("Las horas asignadas deben ser un número no negativo.")
