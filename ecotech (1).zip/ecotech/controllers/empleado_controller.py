"""Operaciones de negocio y persistencia para empleados y horas."""

import sqlite3
from typing import TypedDict

from config.database import Database
from models.empleado import Empleado
from models.proyecto import Proyecto
from models.tiempo import Tiempo
from models.usuario import Usuario


class DatosNuevoEmpleado(TypedDict):
    nombre: str
    email: str
    contrasena: str
    telefono: str
    fecha_inicio_contrato: str
    salario: float
    id_departamento: int


class DatosActualizacionEmpleado(TypedDict):
    nombre: str
    email: str
    telefono: str
    fecha_inicio_contrato: str
    salario: float
    id_departamento: int


class EmpleadoController:
    def __init__(self, database: Database) -> None:
        self.database = database

    def crear_empleado(self, datos: DatosNuevoEmpleado) -> int:
        try:
            campos_texto = (
                "nombre",
                "email",
                "contrasena",
                "telefono",
                "fecha_inicio_contrato",
            )
            if any(not isinstance(datos[campo], str) for campo in campos_texto):
                raise ValueError("Los campos de texto deben contener texto.")
            if not isinstance(datos["salario"], (int, float)) or isinstance(
                datos["salario"], bool
            ):
                raise ValueError("El salario debe ser numérico.")
            if not isinstance(datos["id_departamento"], int) or isinstance(
                datos["id_departamento"], bool
            ):
                raise ValueError("El departamento debe indicarse con un ID entero.")
            contrasena_hash = Usuario.generar_hash(datos["contrasena"])
            empleado = Empleado(
                nombre=datos["nombre"],
                email=datos["email"],
                contrasena_hash=contrasena_hash,
                telefono=datos["telefono"],
                fecha_inicio_contrato=datos["fecha_inicio_contrato"],
                salario=datos["salario"],
                id_departamento=datos["id_departamento"],
            )
            with self.database.transaction() as connection:
                cursor = connection.execute(
                    """INSERT INTO usuario (nombre, email, contrasena_hash, tipo_usuario)
                       VALUES (?, ?, ?, 'empleado')""",
                    (empleado.nombre, empleado.email, empleado.contrasena_hash),
                )
                id_usuario = cursor.lastrowid
                connection.execute(
                    """INSERT INTO empleado
                       (id_usuario, telefono, fecha_inicio_contrato, salario, id_departamento)
                       VALUES (?, ?, ?, ?, ?)""",
                    (
                        id_usuario,
                        empleado.telefono,
                        empleado.fecha_inicio_contrato,
                        empleado.salario,
                        empleado.id_departamento,
                    ),
                )
                return int(id_usuario)
        except sqlite3.Error as exc:
            raise RuntimeError(f"No se pudo crear el empleado: {exc}") from exc
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"Los datos del empleado no son válidos: {exc}") from exc

    def listar_empleados(self) -> list[Empleado]:
        try:
            with self.database.transaction() as connection:
                filas = connection.execute(
                    """SELECT u.id_usuario, u.nombre, u.email, u.contrasena_hash,
                              e.telefono, e.fecha_inicio_contrato, e.salario,
                              e.id_departamento, d.nombre AS departamento,
                              COALESCE(SUM(t.horas_trabajadas), 0) AS horas_totales
                       FROM usuario AS u
                       JOIN empleado AS e ON e.id_usuario = u.id_usuario
                       JOIN departamento AS d ON d.id_departamento = e.id_departamento
                       LEFT JOIN tiempo AS t ON t.id_usuario = e.id_usuario
                       WHERE u.tipo_usuario = 'empleado'
                       GROUP BY u.id_usuario
                       ORDER BY u.nombre"""
                ).fetchall()
                return [
                    Empleado(
                        id_usuario=fila["id_usuario"],
                        nombre=fila["nombre"],
                        email=fila["email"],
                        contrasena_hash=fila["contrasena_hash"],
                        telefono=fila["telefono"] or "",
                        fecha_inicio_contrato=fila["fecha_inicio_contrato"],
                        salario=fila["salario"],
                        id_departamento=fila["id_departamento"],
                        departamento=fila["departamento"],
                        horas_totales=fila["horas_totales"],
                    )
                    for fila in filas
                ]
        except sqlite3.Error as exc:
            raise RuntimeError(f"No se pudieron listar los empleados: {exc}") from exc

    def actualizar_empleado(
        self, id_usuario: int, datos: DatosActualizacionEmpleado
    ) -> bool:
        try:
            campos_texto = (
                "nombre",
                "email",
                "telefono",
                "fecha_inicio_contrato",
            )
            if any(not isinstance(datos[campo], str) for campo in campos_texto):
                raise ValueError("Los campos de texto deben contener texto.")
            if not isinstance(datos["salario"], (int, float)) or isinstance(
                datos["salario"], bool
            ):
                raise ValueError("El salario debe ser numérico.")
            if not isinstance(datos["id_departamento"], int) or isinstance(
                datos["id_departamento"], bool
            ):
                raise ValueError("El departamento debe indicarse con un ID entero.")
            with self.database.transaction() as connection:
                cursor = connection.execute(
                    """UPDATE usuario SET nombre = ?, email = ?
                       WHERE id_usuario = ? AND tipo_usuario = 'empleado'""",
                    (datos["nombre"], datos["email"], id_usuario),
                )
                if cursor.rowcount == 0:
                    return False
                connection.execute(
                    """UPDATE empleado
                       SET telefono = ?, fecha_inicio_contrato = ?, salario = ?,
                           id_departamento = ?
                       WHERE id_usuario = ?""",
                    (
                        datos["telefono"],
                        datos["fecha_inicio_contrato"],
                        datos["salario"],
                        datos["id_departamento"],
                        id_usuario,
                    ),
                )
                return True
        except sqlite3.Error as exc:
            raise RuntimeError(f"No se pudo actualizar el empleado: {exc}") from exc
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"Los datos de actualización no son válidos: {exc}") from exc

    def eliminar_empleado(self, id_usuario: int) -> bool:
        try:
            with self.database.transaction() as connection:
                cursor = connection.execute(
                    "DELETE FROM usuario WHERE id_usuario = ? AND tipo_usuario = 'empleado'",
                    (id_usuario,),
                )
                return cursor.rowcount > 0
        except sqlite3.IntegrityError as exc:
            raise RuntimeError(
                "No se puede eliminar: el empleado tiene registros de horas asociados."
            ) from exc
        except sqlite3.Error as exc:
            raise RuntimeError(f"No se pudo eliminar el empleado: {exc}") from exc

    def listar_departamentos(self) -> list[sqlite3.Row]:
        try:
            with self.database.transaction() as connection:
                return list(
                    connection.execute(
                        "SELECT id_departamento, nombre FROM departamento ORDER BY nombre"
                    ).fetchall()
                )
        except sqlite3.Error as exc:
            raise RuntimeError(f"No se pudieron listar los departamentos: {exc}") from exc

    def listar_proyectos(self) -> list[sqlite3.Row]:
        try:
            with self.database.transaction() as connection:
                return list(
                    connection.execute(
                        "SELECT id_proyecto, nombre FROM proyecto ORDER BY nombre"
                    ).fetchall()
                )
        except sqlite3.Error as exc:
            raise RuntimeError(f"No se pudieron listar los proyectos: {exc}") from exc

    def registrar_horas(
        self,
        id_usuario: int,
        id_proyecto: int,
        fecha: str,
        horas_trabajadas: float,
        descripcion_tareas: str,
    ) -> int:
        try:
            with self.database.transaction() as connection:
                row = connection.execute(
                    """SELECT u.nombre, u.email, u.contrasena_hash, e.salario,
                              e.telefono, e.fecha_inicio_contrato, e.id_departamento
                       FROM usuario AS u
                       JOIN empleado AS e ON e.id_usuario = u.id_usuario
                       WHERE u.id_usuario = ?""",
                    (id_usuario,),
                ).fetchone()
                if row is None:
                    raise ValueError(f"No existe el empleado con ID {id_usuario}.")
                fila_proyecto = connection.execute(
                    """SELECT id_proyecto, nombre, descripcion, fecha_inicio
                       FROM proyecto WHERE id_proyecto = ?""",
                    (id_proyecto,),
                ).fetchone()
                if fila_proyecto is None:
                    raise ValueError(f"No existe el proyecto con ID {id_proyecto}.")
                empleado = Empleado(
                    id_usuario=id_usuario,
                    nombre=row["nombre"],
                    email=row["email"],
                    contrasena_hash=row["contrasena_hash"],
                    salario=row["salario"],
                    telefono=row["telefono"] or "",
                    fecha_inicio_contrato=row["fecha_inicio_contrato"],
                    id_departamento=row["id_departamento"],
                )
                proyecto = Proyecto(
                    id_proyecto=fila_proyecto["id_proyecto"],
                    nombre=fila_proyecto["nombre"],
                    descripcion=fila_proyecto["descripcion"] or "",
                    fecha_inicio=fila_proyecto["fecha_inicio"],
                )
                registro: Tiempo = empleado.registrar_horas(
                    proyecto, horas_trabajadas, descripcion_tareas, fecha
                )
                cursor = connection.execute(
                    """INSERT INTO tiempo
                       (fecha, horas_trabajadas, descripcion_tareas, id_usuario, id_proyecto)
                       VALUES (?, ?, ?, ?, ?)""",
                    (
                        registro.fecha,
                        registro.horas_trabajadas,
                        registro.descripcion_tareas,
                        registro.id_usuario,
                        registro.id_proyecto,
                    ),
                )
                return int(cursor.lastrowid)
        except sqlite3.Error as exc:
            raise RuntimeError(f"No se pudieron registrar las horas: {exc}") from exc

    def actualizar_horas(
        self,
        id_registro: int,
        id_usuario: int,
        id_proyecto: int,
        fecha: str,
        horas_trabajadas: float,
        descripcion_tareas: str,
    ) -> bool:
        try:
            with self.database.transaction() as connection:
                existe = connection.execute(
                    """SELECT 1 FROM tiempo
                       WHERE id_registro = ? AND id_usuario = ?""",
                    (id_registro, id_usuario),
                ).fetchone()
                if existe is None:
                    return False
                empleado_existe = connection.execute(
                    """SELECT 1 FROM empleado WHERE id_usuario = ?""", (id_usuario,)
                ).fetchone()
                if empleado_existe is None:
                    raise ValueError(f"No existe el empleado con ID {id_usuario}.")
                proyecto_existe = connection.execute(
                    "SELECT 1 FROM proyecto WHERE id_proyecto = ?", (id_proyecto,)
                ).fetchone()
                if proyecto_existe is None:
                    raise ValueError(f"No existe el proyecto con ID {id_proyecto}.")
                registro = Tiempo(
                    id_registro=id_registro,
                    fecha=fecha,
                    horas_trabajadas=horas_trabajadas,
                    descripcion_tareas=descripcion_tareas,
                    id_usuario=id_usuario,
                    id_proyecto=id_proyecto,
                )
                if not registro.validar_registro():
                    raise ValueError(
                        "El registro no es válido. Revise la fecha, las horas "
                        "(mayores que 0 y hasta 24) y la descripción."
                    )
                connection.execute(
                    """UPDATE tiempo
                       SET fecha = ?, horas_trabajadas = ?, descripcion_tareas = ?,
                           id_proyecto = ?
                       WHERE id_registro = ? AND id_usuario = ?""",
                    (
                        registro.fecha,
                        registro.horas_trabajadas,
                        registro.descripcion_tareas.strip(),
                        registro.id_proyecto,
                        id_registro,
                        id_usuario,
                    ),
                )
                return True
        except sqlite3.Error as exc:
            raise RuntimeError(f"No se pudo actualizar el registro de horas: {exc}") from exc

    def listar_horas(self, id_usuario: int | None = None) -> list[sqlite3.Row]:
        sql = """SELECT t.id_registro, t.fecha, t.horas_trabajadas,
                        t.descripcion_tareas, u.id_usuario, u.nombre AS empleado,
                        p.nombre AS proyecto
                 FROM tiempo AS t
                 JOIN usuario AS u ON u.id_usuario = t.id_usuario
                 JOIN proyecto AS p ON p.id_proyecto = t.id_proyecto"""
        parametros: tuple[int, ...] = ()
        if id_usuario is not None:
            sql += " WHERE t.id_usuario = ?"
            parametros = (id_usuario,)
        sql += " ORDER BY t.fecha DESC, t.id_registro DESC"
        try:
            with self.database.transaction() as connection:
                return list(connection.execute(sql, parametros).fetchall())
        except sqlite3.Error as exc:
            raise RuntimeError(f"No se pudieron listar los registros de horas: {exc}") from exc
