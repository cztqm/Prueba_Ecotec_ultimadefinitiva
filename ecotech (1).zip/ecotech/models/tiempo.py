"""Modelo de registro de horas trabajadas."""

import math
from datetime import date


class Tiempo:
    def __init__(
        self,
        fecha: str,
        horas_trabajadas: float,
        descripcion_tareas: str,
        id_usuario: int,
        id_proyecto: int,
        id_registro: int | None = None,
    ) -> None:
        self.id_registro = id_registro
        self.fecha = fecha
        self.horas_trabajadas = float(horas_trabajadas)
        self.descripcion_tareas = descripcion_tareas
        self.id_usuario = id_usuario
        self.id_proyecto = id_proyecto

    def validar_registro(self) -> bool:
        """Valida fecha ISO, horas de hasta un día y campos requeridos."""
        try:
            date.fromisoformat(self.fecha)
        except (TypeError, ValueError):
            return False
        return (
            math.isfinite(self.horas_trabajadas)
            and 0 < self.horas_trabajadas <= 24
            and bool(self.descripcion_tareas.strip())
            and self.id_usuario > 0
            and self.id_proyecto > 0
        )
