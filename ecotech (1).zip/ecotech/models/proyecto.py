"""Modelo de proyecto y sus empleados asignados."""

from __future__ import annotations

from datetime import date
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from models.empleado import Empleado


class Proyecto:
    def __init__(
        self,
        nombre: str,
        descripcion: str,
        fecha_inicio: str,
        id_proyecto: int | None = None,
        empleados: list[Empleado] | None = None,
        empleados_asignados: int = 0,
        horas_asignadas: float = 0,
    ) -> None:
        self.id_proyecto = id_proyecto
        self.nombre = nombre
        self.descripcion = descripcion
        self.fecha_inicio = fecha_inicio
        self.empleados = list(empleados or [])
        self.empleados_asignados = empleados_asignados
        self.horas_asignadas = horas_asignadas

    def validar(self) -> bool:
        try:
            date.fromisoformat(self.fecha_inicio)
        except (TypeError, ValueError):
            return False
        return bool(self.nombre.strip())

    def asignar_empleado(self, empleado: Empleado) -> None:
        if empleado.id_usuario is None:
            raise ValueError("El empleado debe estar guardado antes de asignarlo.")
        if any(actual.id_usuario == empleado.id_usuario for actual in self.empleados):
            raise ValueError("El empleado ya está asignado a este proyecto.")
        self.empleados.append(empleado)

    def desasignar_empleado(self, empleado: Empleado) -> None:
        if not any(actual.id_usuario == empleado.id_usuario for actual in self.empleados):
            raise ValueError("El empleado no está asignado a este proyecto.")
        self.empleados = [
            actual for actual in self.empleados if actual.id_usuario != empleado.id_usuario
        ]
