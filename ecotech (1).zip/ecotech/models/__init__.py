"""Modelos del dominio de EcoTech Solutions."""
