"""Modelo base de usuarios y utilidades de autenticación."""

import hashlib
import hmac
import secrets


class Usuario:
    """Entidad base para empleados y administradores."""

    _ITERACIONES_HASH = 310_000

    def __init__(
        self,
        nombre: str,
        email: str,
        contrasena_hash: str,
        id_usuario: int | None = None,
    ) -> None:
        self._id_usuario = id_usuario
        self._nombre = nombre
        self._email = email
        self._contrasena_hash = contrasena_hash

    @property
    def id_usuario(self) -> int | None:
        return self._id_usuario

    @property
    def nombre(self) -> str:
        return self._nombre

    @property
    def email(self) -> str:
        return self._email

    @property
    def contrasena_hash(self) -> str:
        return self._contrasena_hash

    @classmethod
    def generar_hash(cls, contrasena: str) -> str:
        """Genera un hash PBKDF2 con sal aleatoria, listo para almacenar."""
        if not contrasena:
            raise ValueError("La contraseña no puede estar vacía.")
        salt = secrets.token_hex(16)
        digest = hashlib.pbkdf2_hmac(
            "sha256", contrasena.encode("utf-8"), salt.encode("ascii"), cls._ITERACIONES_HASH
        ).hex()
        return f"pbkdf2_sha256${cls._ITERACIONES_HASH}${salt}${digest}"

    @staticmethod
    def _verificar_hash(contrasena: str, contrasena_hash: str) -> bool:
        try:
            algoritmo, iteraciones, salt, digest_esperado = contrasena_hash.split("$", 3)
            if algoritmo != "pbkdf2_sha256":
                return False
            digest = hashlib.pbkdf2_hmac(
                "sha256", contrasena.encode("utf-8"), salt.encode("ascii"), int(iteraciones)
            ).hex()
            return hmac.compare_digest(digest, digest_esperado)
        except (ValueError, TypeError):
            return False

    def autenticar(self, contrasena: str) -> bool:
        """Comprueba una contraseña contra el hash almacenado."""
        return self._verificar_hash(contrasena, self._contrasena_hash)

    def cambiar_contrasena(self, actual: str, nueva: str) -> bool:
        """Cambia la contraseña solo si la contraseña actual es correcta."""
        if not self.autenticar(actual):
            return False
        self._contrasena_hash = self.generar_hash(nueva)
        return True
