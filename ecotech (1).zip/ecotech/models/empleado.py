"""Modelo de empleado, especializado a partir de Usuario."""

from datetime import date

from models.proyecto import Proyecto
from models.tiempo import Tiempo
from models.usuario import Usuario


class Empleado(Usuario):
    def __init__(
        self,
        nombre: str,
        email: str,
        contrasena_hash: str,
        salario: float,
        telefono: str,
        fecha_inicio_contrato: str,
        id_departamento: int,
        id_usuario: int | None = None,
        departamento: str = "",
        horas_totales: float = 0,
    ) -> None:
        super().__init__(nombre, email, contrasena_hash, id_usuario)
        self._salario = float(salario)
        self._telefono = telefono
        self._fecha_inicio_contrato = fecha_inicio_contrato
        self._id_departamento = id_departamento
        self._departamento = departamento
        self._horas_totales = float(horas_totales)

    @property
    def salario(self) -> float:
        return self._salario

    @property
    def telefono(self) -> str:
        return self._telefono

    @property
    def fecha_inicio_contrato(self) -> str:
        return self._fecha_inicio_contrato

    @property
    def id_departamento(self) -> int:
        return self._id_departamento

    @property
    def departamento(self) -> str:
        return self._departamento

    @property
    def horas_totales(self) -> float:
        return self._horas_totales

    def registrar_horas(
        self,
        proyecto: Proyecto,
        horas: float,
        desc: str,
        fecha: str | None = None,
    ) -> Tiempo:
        """Crea un registro validado que el controlador persiste en SQLite."""
        if self.id_usuario is None:
            raise ValueError("El empleado debe estar guardado antes de registrar horas.")
        if proyecto.id_proyecto is None:
            raise ValueError("El proyecto debe estar guardado antes de registrar horas.")
        registro = Tiempo(
            fecha=fecha or date.today().isoformat(),
            horas_trabajadas=horas,
            descripcion_tareas=desc,
            id_usuario=self.id_usuario,
            id_proyecto=proyecto.id_proyecto,
        )
        if not registro.validar_registro():
            raise ValueError(
                "El registro no es válido. Revise la fecha, las horas (mayores que "
                "0 y hasta 24) y la descripción."
            )
        return registro
