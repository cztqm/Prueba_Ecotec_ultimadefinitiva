"""Funciones reutilizables para la entrada de datos por consola."""

import re


def extraer_entero(entrada: str) -> int:
    """Extrae el primer entero de una entrada con etiquetas o puntuación."""
    coincidencia = re.search(r"-?\d+", entrada)
    if coincidencia is None:
        raise ValueError("La entrada no contiene un número entero.")
    return int(coincidencia.group())


def leer_entero(mensaje: str, minimo: int | None = None) -> int:
    while True:
        try:
            valor = extraer_entero(input(mensaje).strip())
            if minimo is not None and valor < minimo:
                print(f"Ingrese un número igual o mayor que {minimo}.")
                continue
            return valor
        except ValueError:
            print("Entrada inválida. Ingrese un número entero y vuelva a intentar.")


def leer_decimal(mensaje: str, minimo: float | None = None) -> float:
    while True:
        try:
            valor = float(input(mensaje).strip().replace(",", "."))
            if minimo is not None and valor < minimo:
                print(f"Ingrese un número igual o mayor que {minimo}.")
                continue
            return valor
        except ValueError:
            print("Entrada inválida. Ingrese un número válido.")


def leer_texto(mensaje: str, obligatorio: bool = True) -> str:
    while True:
        valor = input(mensaje).strip()
        if valor or not obligatorio:
            return valor
        print("Este campo es obligatorio.")


def confirmar(mensaje: str) -> bool:
    while True:
        respuesta = input(f"{mensaje} (si/no): ").strip().lower()
        if respuesta in {"si", "sí"}:
            return True
        if respuesta == "no":
            return False
        print("Responda 'si' o 'no'.")
