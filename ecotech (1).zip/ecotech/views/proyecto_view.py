"""Menú de consola para la gestión de proyectos y asignaciones."""

from controllers.proyecto_controller import DatosProyecto, ProyectoController
from views.utils import confirmar, leer_decimal, leer_entero, leer_texto


class ProyectoView:
    def __init__(self, controller: ProyectoController) -> None:
        self.controller = controller

    def menu(self) -> None:
        while True:
            print(
                "\n--- Gestión de proyectos ---\n"
                "1. Registrar proyecto\n"
                "2. Listar proyectos\n"
                "3. Actualizar proyecto\n"
                "4. Eliminar proyecto\n"
                "5. Asignar varios empleados y horas planificadas\n"
                "6. Desasignar empleado de proyecto\n"
                "7. Ver empleados y horas asignadas\n"
                "8. Modificar horas asignadas\n"
                "0. Volver al menú principal"
            )
            opcion = leer_entero("Seleccione una opción: ", minimo=0)
            acciones = {
                1: self._registrar_proyecto,
                2: self._listar_proyectos,
                3: self._actualizar_proyecto,
                4: self._eliminar_proyecto,
                5: self._asignar_empleado,
                6: self._desasignar_empleado,
                7: self._listar_asignaciones,
                8: self._actualizar_horas_asignadas,
            }
            if opcion == 0:
                return
            accion = acciones.get(opcion)
            if accion is None:
                print("Opción no válida.")
                continue
            try:
                accion()
            except (RuntimeError, ValueError) as exc:
                print(f"Error: {exc}")

    def _registrar_proyecto(self) -> None:
        datos = self._leer_datos_proyecto()
        if confirmar("¿Confirma el registro del proyecto?"):
            id_proyecto = self.controller.crear_proyecto(datos)
            print(f"Proyecto creado con ID {id_proyecto}.")
        else:
            print("Registro cancelado.")

    def _actualizar_proyecto(self) -> None:
        id_proyecto = self._seleccionar_proyecto()
        if id_proyecto is None:
            return
        datos = self._leer_datos_proyecto()
        if confirmar("¿Confirma la actualización del proyecto?"):
            if self.controller.actualizar_proyecto(id_proyecto, datos):
                print("Proyecto actualizado.")
            else:
                print("No se encontró el proyecto indicado.")
        else:
            print("Actualización cancelada.")

    def _eliminar_proyecto(self) -> None:
        id_proyecto = self._seleccionar_proyecto()
        if id_proyecto is None:
            return
        if confirmar("¿Confirma la eliminación del proyecto?"):
            if self.controller.eliminar_proyecto(id_proyecto):
                print("Proyecto eliminado.")
            else:
                print("No se encontró el proyecto indicado.")
        else:
            print("Eliminación cancelada.")

    @staticmethod
    def _leer_datos_proyecto() -> DatosProyecto:
        return {
            "nombre": leer_texto("Nombre: "),
            "descripcion": leer_texto("Descripción (opcional): ", obligatorio=False),
            "fecha_inicio": leer_texto("Fecha de inicio (AAAA-MM-DD): "),
        }

    def _listar_proyectos(self) -> None:
        proyectos = self.controller.listar_proyectos()
        if not proyectos:
            print("No hay proyectos registrados.")
            return
        print(
            "\nID | Nombre | Fecha de inicio | Empleados asignados | "
            "Horas planificadas | Descripción"
        )
        for proyecto in proyectos:
            print(
                f"{proyecto.id_proyecto} | {proyecto.nombre} | "
                f"{proyecto.fecha_inicio} | {proyecto.empleados_asignados} | "
                f"{proyecto.horas_asignadas:g} | "
                f"{proyecto.descripcion or '-'}"
            )

    def _asignar_empleado(self) -> None:
        proyecto_id = self._seleccionar_proyecto()
        if proyecto_id is None:
            return
        asignados = {
            asignacion["id_usuario"]
            for asignacion in self.controller.listar_asignaciones(proyecto_id)
        }
        empleados_disponibles = [
            empleado
            for empleado in self.controller.listar_empleados()
            if empleado["id_usuario"] not in asignados
        ]
        if not empleados_disponibles:
            print("No hay empleados disponibles para asignar a este proyecto.")
            return
        asignaciones: list[tuple[int, float]] = []
        while True:
            empleado_id = self._seleccionar_empleado(
                empleados_disponibles, {id_usuario for id_usuario, _ in asignaciones}
            )
            if empleado_id is None:
                return
            horas = leer_decimal("Horas planificadas para este empleado: ", minimo=0)
            if horas <= 0:
                print("Las horas planificadas deben ser mayores que cero.")
                continue
            asignaciones.append((empleado_id, horas))
            if len(asignaciones) == len(empleados_disponibles) or not confirmar(
                "¿Desea agregar otro empleado?"
            ):
                break
        if confirmar("¿Confirma las asignaciones y horas planificadas?"):
            self.controller.asignar_empleados(proyecto_id, asignaciones)
            print("Empleados y horas asignados al proyecto.")
        else:
            print("Asignación cancelada.")

    def _desasignar_empleado(self) -> None:
        proyecto_id = self._seleccionar_proyecto()
        if proyecto_id is None:
            return
        asignaciones = self.controller.listar_asignaciones(proyecto_id)
        if not asignaciones:
            print("El proyecto no tiene empleados asignados.")
            return
        empleado_id = self._seleccionar_empleado(asignaciones)
        if empleado_id is None:
            return
        if confirmar("¿Confirma la desasignación?"):
            self.controller.desasignar_empleado(proyecto_id, empleado_id)
            print("Empleado desasignado del proyecto.")
        else:
            print("Desasignación cancelada.")

    def _listar_asignaciones(self) -> None:
        proyecto_id = self._seleccionar_proyecto()
        if proyecto_id is None:
            return
        asignaciones = self.controller.listar_asignaciones(proyecto_id)
        if not asignaciones:
            print("El proyecto no tiene empleados asignados.")
            return
        print("\nID | Empleado | Email | Horas planificadas")
        for asignacion in asignaciones:
            print(
                f"{asignacion['id_usuario']} | {asignacion['nombre']} | "
                f"{asignacion['email']} | {asignacion['horas_asignadas']:g}"
            )

    def _actualizar_horas_asignadas(self) -> None:
        proyecto_id = self._seleccionar_proyecto()
        if proyecto_id is None:
            return
        asignaciones = self.controller.listar_asignaciones(proyecto_id)
        if not asignaciones:
            print("El proyecto no tiene empleados asignados.")
            return
        empleado_id = self._seleccionar_empleado(asignaciones)
        if empleado_id is None:
            return
        horas = leer_decimal("Nueva cantidad de horas planificadas: ", minimo=0)
        if horas <= 0:
            print("Las horas planificadas deben ser mayores que cero.")
            return
        if confirmar("¿Confirma el cambio de horas asignadas?"):
            if self.controller.actualizar_horas_asignadas(
                proyecto_id, empleado_id, horas
            ):
                print("Horas planificadas actualizadas.")
            else:
                print("El empleado ya no está asignado a este proyecto.")
        else:
            print("Actualización cancelada.")

    def _seleccionar_proyecto(self) -> int | None:
        proyectos = self.controller.listar_proyectos()
        if not proyectos:
            print("No hay proyectos registrados.")
            return None
        print("\nProyectos:")
        for proyecto in proyectos:
            print(f"{proyecto.id_proyecto}. {proyecto.nombre}")
        ids = {proyecto.id_proyecto for proyecto in proyectos}
        while True:
            id_proyecto = leer_entero("ID del proyecto: ", minimo=1)
            if id_proyecto in ids:
                return id_proyecto
            print("El ID seleccionado no corresponde a un proyecto.")

    def _seleccionar_empleado(self, empleados=None, excluidos=None) -> int | None:
        if empleados is None:
            empleados = self.controller.listar_empleados()
        excluidos = excluidos or set()
        empleados = [
            empleado
            for empleado in empleados
            if empleado["id_usuario"] not in excluidos
        ]
        if not empleados:
            print("No hay empleados disponibles en esta selección.")
            return None
        print("\nEmpleados:")
        for empleado in empleados:
            print(f"{empleado['id_usuario']}. {empleado['nombre']} ({empleado['email']})")
        ids = {empleado["id_usuario"] for empleado in empleados}
        while True:
            id_usuario = leer_entero("ID del empleado: ", minimo=1)
            if id_usuario in ids:
                return id_usuario
            if id_usuario in excluidos:
                print("Ese empleado ya fue seleccionado.")
                continue
            print("El ID seleccionado no corresponde a un empleado.")
