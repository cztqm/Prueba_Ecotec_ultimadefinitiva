"""Menús de consola para la gestión de empleados y registros de tiempo."""

from datetime import date

from controllers.empleado_controller import (
    DatosActualizacionEmpleado,
    DatosNuevoEmpleado,
    EmpleadoController,
)
from views.utils import confirmar, extraer_entero, leer_decimal, leer_entero, leer_texto


class EmpleadoView:
    def __init__(self, controller: EmpleadoController) -> None:
        self.controller = controller

    def menu(self) -> None:
        while True:
            print(
                "\n--- Gestión de empleados y horas ---\n"
                "1. Registrar empleado\n"
                "2. Listar empleados\n"
                "3. Actualizar empleado\n"
                "4. Eliminar empleado\n"
                "5. Registrar horas\n"
                "6. Listar registros de horas\n"
                "7. Modificar registro de horas\n"
                "0. Volver al menú principal"
            )
            opcion = leer_entero("Seleccione una opción: ", minimo=0)
            acciones = {
                1: self._registrar_empleado,
                2: self._listar_empleados,
                3: self._actualizar_empleado,
                4: self._eliminar_empleado,
                5: self._registrar_horas,
                6: self._listar_horas,
                7: self._actualizar_horas,
            }
            if opcion == 0:
                return
            accion = acciones.get(opcion)
            if accion is None:
                print("Opción no válida.")
            else:
                try:
                    accion()
                except (RuntimeError, ValueError) as exc:
                    print(f"Error: {exc}")

    def _seleccionar_departamento(self):
        departamentos = self.controller.listar_departamentos()
        if not departamentos:
            print("No hay departamentos cargados. Registre uno en la base de datos primero.")
            return None
        print("\nDepartamentos:")
        for departamento in departamentos:
            print(f"{departamento['id_departamento']}. {departamento['nombre']}")
        ids = {departamento["id_departamento"] for departamento in departamentos}
        while True:
            id_departamento = leer_entero("ID del departamento: ", minimo=1)
            if id_departamento in ids:
                return id_departamento
            print("El ID seleccionado no corresponde a un departamento.")

    def _registrar_empleado(self) -> None:
        id_departamento = self._seleccionar_departamento()
        if id_departamento is None:
            return
        nombre = leer_texto("Nombre: ")
        email = leer_texto("Email: ")
        contrasena = leer_texto("Contraseña: ")
        telefono = leer_texto("Teléfono (opcional): ", obligatorio=False)
        fecha = leer_texto("Fecha de inicio (AAAA-MM-DD): ")
        salario = leer_decimal("Salario: ", minimo=0)
        if confirmar("¿Confirma el registro del empleado?"):
            datos: DatosNuevoEmpleado = {
                "nombre": nombre,
                "email": email,
                "contrasena": contrasena,
                "telefono": telefono,
                "fecha_inicio_contrato": fecha,
                "salario": salario,
                "id_departamento": id_departamento,
            }
            id_usuario = self.controller.crear_empleado(datos)
            print(f"Empleado creado con ID {id_usuario}.")
        else:
            print("Registro cancelado.")

    def _listar_empleados(self) -> None:
        empleados = self.controller.listar_empleados()
        if not empleados:
            print("No hay empleados registrados.")
            return
        print(
            "\nID | Nombre | Email | Teléfono | Inicio | Salario | "
            "Departamento | Horas registradas"
        )
        for empleado in empleados:
            print(
                f"{empleado.id_usuario} | {empleado.nombre} | {empleado.email} | "
                f"{empleado.telefono or '-'} | {empleado.fecha_inicio_contrato} | "
                f"{empleado.salario:.2f} | {empleado.departamento} | "
                f"{empleado.horas_totales:g}"
            )

    def _actualizar_empleado(self) -> None:
        id_usuario = leer_entero("ID del empleado a actualizar: ", minimo=1)
        id_departamento = self._seleccionar_departamento()
        if id_departamento is None:
            return
        nombre = leer_texto("Nuevo nombre: ")
        email = leer_texto("Nuevo email: ")
        telefono = leer_texto("Nuevo teléfono (opcional): ", obligatorio=False)
        fecha = leer_texto("Nueva fecha de inicio (AAAA-MM-DD): ")
        salario = leer_decimal("Nuevo salario: ", minimo=0)
        if confirmar("¿Confirma la actualización?"):
            datos: DatosActualizacionEmpleado = {
                "nombre": nombre,
                "email": email,
                "telefono": telefono,
                "fecha_inicio_contrato": fecha,
                "salario": salario,
                "id_departamento": id_departamento,
            }
            if self.controller.actualizar_empleado(id_usuario, datos):
                print("Empleado actualizado.")
            else:
                print("No se encontró el empleado indicado.")
        else:
            print("Actualización cancelada.")

    def _eliminar_empleado(self) -> None:
        id_usuario = leer_entero("ID del empleado a eliminar: ", minimo=1)
        if confirmar("¿Confirma la eliminación?"):
            if self.controller.eliminar_empleado(id_usuario):
                print("Empleado eliminado.")
            else:
                print("No se encontró el empleado indicado.")
        else:
            print("Eliminación cancelada.")

    def _registrar_horas(self) -> None:
        id_usuario = self._seleccionar_empleado()
        if id_usuario is None:
            return
        proyectos = self.controller.listar_proyectos()
        if not proyectos:
            print("No hay proyectos cargados. Registre uno en la base de datos primero.")
            return
        id_proyecto = self._seleccionar_proyecto(proyectos)
        if id_proyecto is None:
            return
        fecha = leer_texto(
            f"Fecha (AAAA-MM-DD, Enter para {date.today().isoformat()}): ",
            obligatorio=False,
        )
        fecha = fecha or date.today().isoformat()
        horas = leer_decimal("Horas trabajadas: ", minimo=0)
        descripcion = leer_texto("Descripción de tareas: ")
        if confirmar("¿Confirma el registro de horas?"):
            id_registro = self.controller.registrar_horas(
                id_usuario, id_proyecto, fecha, horas, descripcion
            )
            print(f"Registro creado con ID {id_registro}.")
        else:
            print("Registro cancelado.")

    def _actualizar_horas(self) -> None:
        id_usuario = self._seleccionar_empleado()
        if id_usuario is None:
            return
        registros = self.controller.listar_horas(id_usuario)
        if not registros:
            print("El empleado seleccionado no tiene registros de horas.")
            return
        print("\nID | Fecha | Proyecto | Horas | Tareas")
        for registro in registros:
            print(
                f"{registro['id_registro']} | {registro['fecha']} | "
                f"{registro['proyecto']} | {registro['horas_trabajadas']:g} | "
                f"{registro['descripcion_tareas']}"
            )
        ids_registros = {registro["id_registro"] for registro in registros}
        while True:
            id_registro = leer_entero("ID del registro a modificar: ", minimo=1)
            if id_registro in ids_registros:
                break
            print("El ID seleccionado no corresponde a un registro de este empleado.")

        registro_actual = next(
            registro for registro in registros if registro["id_registro"] == id_registro
        )
        proyectos = self.controller.listar_proyectos()
        if not proyectos:
            print("No hay proyectos cargados.")
            return
        id_proyecto = self._seleccionar_proyecto(proyectos)
        if id_proyecto is None:
            return
        fecha = leer_texto(
            f"Fecha (AAAA-MM-DD, Enter para {registro_actual['fecha']}): ",
            obligatorio=False,
        )
        fecha = fecha or registro_actual["fecha"]
        horas = leer_decimal("Nueva cantidad de horas trabajadas: ", minimo=0)
        descripcion = leer_texto("Nueva descripción de tareas: ")
        if confirmar("¿Confirma la actualización del registro?"):
            if self.controller.actualizar_horas(
                id_registro, id_usuario, id_proyecto, fecha, horas, descripcion
            ):
                print("Registro de horas actualizado.")
            else:
                print("No se encontró el registro de horas indicado.")
        else:
            print("Actualización cancelada.")

    def _listar_horas(self) -> None:
        id_usuario = leer_texto(
            "ID de empleado para filtrar (Enter para todos): ", obligatorio=False
        )
        registros = self.controller.listar_horas(int(id_usuario) if id_usuario else None)
        if not registros:
            print("No hay registros de horas.")
            return
        print("\nID | Fecha | Empleado (ID) | Proyecto | Horas | Tareas")
        for registro in registros:
            print(
                f"{registro['id_registro']} | {registro['fecha']} | "
                f"{registro['empleado']} ({registro['id_usuario']}) | "
                f"{registro['proyecto']} | {registro['horas_trabajadas']:.2f} | "
                f"{registro['descripcion_tareas']}"
            )

    def _seleccionar_empleado(self) -> int | None:
        empleados = self.controller.listar_empleados()
        if not empleados:
            print("No hay empleados registrados.")
            return None
        print("\nEmpleados:")
        for opcion, empleado in enumerate(empleados, start=1):
            print(f"{opcion}. {empleado.nombre} (ID {empleado.id_usuario})")

        while True:
            entrada = leer_texto(
                "Seleccione el número de opción o el ID del empleado: "
            ).strip()
            tipo_explicito = None
            entrada_normalizada = entrada.casefold()
            if entrada_normalizada.startswith("opción") or entrada_normalizada.startswith(
                "opcion"
            ):
                tipo_explicito = "opcion"
            elif entrada_normalizada.startswith("id"):
                tipo_explicito = "id"
            try:
                seleccion = extraer_entero(entrada)
            except ValueError:
                print("Ingrese un ID o número de opción válido e intente de nuevo.")
                continue

            por_id = next(
                (
                    empleado
                    for empleado in empleados
                    if empleado.id_usuario == seleccion
                ),
                None,
            )
            por_opcion = (
                empleados[seleccion - 1]
                if 1 <= seleccion <= len(empleados)
                else None
            )
            if tipo_explicito == "id":
                elegido = por_id
            elif tipo_explicito == "opcion":
                elegido = por_opcion
            elif por_id is not None and por_opcion is not None:
                if por_id.id_usuario != por_opcion.id_usuario:
                    print(
                        "La entrada coincide con un ID y una opción distintos. "
                        "Escriba 'ID N' o 'Opción N' para especificar."
                    )
                    continue
                elegido = por_id
            else:
                elegido = por_id or por_opcion
            if elegido is not None and elegido.id_usuario is not None:
                return elegido.id_usuario
            print("La selección no corresponde a un empleado registrado.")

    @staticmethod
    def _seleccionar_proyecto(proyectos) -> int | None:
        if not proyectos:
            return None
        print("\nProyectos:")
        for proyecto in proyectos:
            print(f"{proyecto['id_proyecto']}. {proyecto['nombre']}")
        ids = {proyecto["id_proyecto"] for proyecto in proyectos}
        while True:
            id_proyecto = leer_entero("ID del proyecto: ", minimo=1)
            if id_proyecto in ids:
                return id_proyecto
            print("El ID seleccionado no corresponde a un proyecto.")
