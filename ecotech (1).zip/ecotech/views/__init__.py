"""Interfaz de consola."""
