"""Conexión y esquema SQLite de EcoTech Solutions."""

import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Generator


class Database:
    """Administra la conexión y la inicialización de la base de datos local."""

    def __init__(self, db_path: str | Path | None = None) -> None:
        self.db_path = Path(db_path) if db_path else Path(__file__).resolve().parents[1] / "ecotech.db"

    def connect(self) -> sqlite3.Connection:
        """Abre una conexión con claves foráneas habilitadas."""
        try:
            connection = sqlite3.connect(self.db_path)
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA foreign_keys = ON")
            return connection
        except sqlite3.Error as exc:
            raise sqlite3.DatabaseError(f"No se pudo conectar con {self.db_path}: {exc}") from exc

    @contextmanager
    def transaction(self) -> Generator[sqlite3.Connection, None, None]:
        """Gestiona commit, rollback y cierre de una conexión."""
        connection = self.connect()
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def init_db(self) -> None:
        """Crea las tablas si todavía no existen."""
        schema = """
        CREATE TABLE IF NOT EXISTS departamento (
            id_departamento INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL UNIQUE
        );

        CREATE TABLE IF NOT EXISTS usuario (
            id_usuario INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            contrasena_hash TEXT NOT NULL,
            tipo_usuario TEXT NOT NULL
                CHECK (tipo_usuario IN ('empleado', 'administrador'))
        );

        CREATE TABLE IF NOT EXISTS empleado (
            id_usuario INTEGER PRIMARY KEY,
            telefono TEXT,
            fecha_inicio_contrato TEXT NOT NULL,
            salario REAL NOT NULL CHECK (salario >= 0),
            id_departamento INTEGER NOT NULL,
            FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario) ON DELETE CASCADE,
            FOREIGN KEY (id_departamento) REFERENCES departamento(id_departamento)
        );

        CREATE TABLE IF NOT EXISTS administrador (
            id_usuario INTEGER PRIMARY KEY,
            FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS proyecto (
            id_proyecto INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            descripcion TEXT,
            fecha_inicio TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS empleado_proyecto (
            id_usuario INTEGER NOT NULL,
            id_proyecto INTEGER NOT NULL,
            horas_asignadas REAL NOT NULL DEFAULT 0
                CHECK (horas_asignadas >= 0),
            PRIMARY KEY (id_usuario, id_proyecto),
            FOREIGN KEY (id_usuario) REFERENCES empleado(id_usuario) ON DELETE CASCADE,
            FOREIGN KEY (id_proyecto) REFERENCES proyecto(id_proyecto) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_empleado_proyecto_proyecto
            ON empleado_proyecto(id_proyecto, id_usuario);

        CREATE TABLE IF NOT EXISTS tiempo (
            id_registro INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha TEXT NOT NULL,
            horas_trabajadas REAL NOT NULL
                CHECK (horas_trabajadas > 0 AND horas_trabajadas <= 24),
            descripcion_tareas TEXT NOT NULL,
            id_usuario INTEGER NOT NULL,
            id_proyecto INTEGER NOT NULL,
            FOREIGN KEY (id_usuario) REFERENCES empleado(id_usuario),
            FOREIGN KEY (id_proyecto) REFERENCES proyecto(id_proyecto)
        );

        CREATE INDEX IF NOT EXISTS idx_tiempo_usuario_fecha
            ON tiempo(id_usuario, fecha);
        """
        try:
            with self.transaction() as connection:
                connection.executescript(schema)
                columnas_asignacion = {
                    fila["name"]
                    for fila in connection.execute(
                        "PRAGMA table_info(empleado_proyecto)"
                    ).fetchall()
                }
                if "horas_asignadas" not in columnas_asignacion:
                    connection.execute(
                        """ALTER TABLE empleado_proyecto
                           ADD COLUMN horas_asignadas REAL NOT NULL DEFAULT 0
                           CHECK (horas_asignadas >= 0)"""
                    )
                connection.execute(
                    "INSERT OR IGNORE INTO departamento (nombre) VALUES (?)",
                    ("General",),
                )
        except sqlite3.Error as exc:
            raise sqlite3.DatabaseError(f"No se pudo inicializar la base de datos: {exc}") from exc
