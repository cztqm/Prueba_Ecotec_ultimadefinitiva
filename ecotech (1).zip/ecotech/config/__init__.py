"""Configuración y acceso a servicios compartidos."""
